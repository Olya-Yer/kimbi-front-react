import React, { Component } from 'react'
import Header from './header'
import HomeMain from './homeMain'
import Footer from './footer'

class Home extends Component {

    render() {
        return (
            <div>
                <Header />
                <HomeMain />
                <Footer />
            </div>

        )
    }
}

export default Home;