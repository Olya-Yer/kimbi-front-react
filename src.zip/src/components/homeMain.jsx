import React, { Component } from 'react'

class HomeMain extends Component {
    render() {
        return (<div></div>)
    }
}
export default HomeMain;